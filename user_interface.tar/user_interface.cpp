//=====[Libraries]=============================================================

#include "mbed.h" //need to compare the thing
#include "arm_book_lib.h"

#include "user_interface.h"

#include "alarm.h"
#include "alarm_clock_system.h"
#include "date_and_time.h"
#include "motion_sensor.h"
#include "siren.h"
#include "display.h"
#include "GLCD_fire_alarm.h"// what is this?? 
#include "GLCD_intruder_alarm.h"
#include "servo_motor.h"
#include "light_control.h"

//=====[Declaration of private defines]========================================

#define DISPLAY_REFRESH_TIME_REPORT_MS 1000
#define DISPLAY_REFRESH_TIME_ALARM_MS 300

//=====[Declaration of private data types]=====================================

typedef enum {
    DISPLAY_ALARM_STATE,
    DISPLAY_REPORT_STATE
} displayState_t;

//=====[Declaration and initialization of public global objects]===============



//=====[Declaration of external public global variables]=======================

//=====[Declaration and initialization of public global variables]=============


//=====[Declaration and initialization of private global variables]============

static displayState_t displayState = DISPLAY_REPORT_STATE;
static int displayFireAlarmGraphicSequence = 0; // delete
static int displayIntruderAlarmGraphicSequence = 0; //delete
static int displayRefreshTimeMs = DISPLAY_REFRESH_TIME_REPORT_MS;//



//=====[Declarations (prototypes) of private functions]========================



static void userInterfaceDisplayInit();
static void userInterfaceDisplayUpdate();
static void userInterfaceDisplayReportStateInit();
static void userInterfaceDisplayReportStateUpdate();
static void userInterfaceDisplayAlarmStateInit();
static void userInterfaceDisplayAlarmStateUpdate();

static void gateOpenButtonCallback();
static void gateCloseButtonCallback();

//=====[Implementations of public functions]===================================

void userInterfaceInit()
{
   
    userInterfaceDisplayInit();//
    
    lightLevelControlInit();
}

void userInterfaceUpdate()
{
  
    lightLevelControlUpdate();
}


//=====[Implementations of private functions]==================================


static void userInterfaceDisplayReportStateInit()
{
    displayState = DISPLAY_REPORT_STATE;
    displayRefreshTimeMs = DISPLAY_REFRESH_TIME_REPORT_MS;

    displayModeWrite( DISPLAY_MODE_CHAR );

    displayClear();

    displayCharPositionWrite ( 0,0 );
    displayStringWrite( "Time:" );// says the time delete


    displayCharPositionWrite ( 0,1 );
    displayStringWrite( "Alarm:" );
}

static void userInterfaceDisplayReportStateUpdate()
{
    char alarmTimeString[3] = "";

    sprintf(alarmTimeString, alarmDateAndTimeRead());
    displayCharPositionWrite ( 12,0 );
    displayStringWrite( alarmTimeString); //would it fit? 
    displayCharPositionWrite ( 14,0 );
    displayStringWrite( "'C" );

    displayCharPositionWrite ( 6,1 );

    if ( alarmState() ) {///alarmState correspond this variable 
        displayStringWrite( " ON" );
    } else {
        displayStringWrite( " OFF" );
    }
}

static void userInterfaceDisplayAlarmStateInit()
{
    displayState = DISPLAY_ALARM_STATE;
    displayRefreshTimeMs = DISPLAY_REFRESH_TIME_ALARM_MS;

    displayClear();

    displayModeWrite( DISPLAY_MODE_GRAPHIC );

    displayFireAlarmGraphicSequence = 0;
}

static void userInterfaceDisplayAlarmStateUpdate()
{
    if ( ( gasDetectedRead() ) || ( overTemperatureDetectedRead() ) ) {
        switch( displayFireAlarmGraphicSequence ) {
        case 0:
            displayBitmapWrite( GLCD_fire_alarm[0] );
            displayFireAlarmGraphicSequence++;
            break;
        case 1:
            displayBitmapWrite( GLCD_fire_alarm[1] );
            displayFireAlarmGraphicSequence++;
            break;
        case 2:
            displayBitmapWrite( GLCD_fire_alarm[2] );
            displayFireAlarmGraphicSequence++;
            break;
        case 3:
            displayBitmapWrite( GLCD_fire_alarm[3] );
            displayFireAlarmGraphicSequence = 0;
            break;
        default:
            displayBitmapWrite( GLCD_ClearScreen );
            displayFireAlarmGraphicSequence = 0;
            break;
        }
    } else if ( intruderDetectedRead() ) {
        switch( displayIntruderAlarmGraphicSequence ) {
        case 0:
            displayBitmapWrite( GLCD_intruder_alarm );
            displayIntruderAlarmGraphicSequence++;
            break;
        case 1:
        default:
            displayBitmapWrite( GLCD_ClearScreen );
            displayIntruderAlarmGraphicSequence = 0;
            break;
        }
    }
}

static void userInterfaceDisplayInit()
{
    displayInit( DISPLAY_TYPE_GLCD_ST7920, DISPLAY_CONNECTION_SPI );
    userInterfaceDisplayReportStateInit();
}

static void userInterfaceDisplayUpdate()
{
    static int accumulatedDisplayTime = 0;

    if( accumulatedDisplayTime >=
        displayRefreshTimeMs ) {

        accumulatedDisplayTime = 0;

        switch ( displayState ) {
        case DISPLAY_REPORT_STATE:
            userInterfaceDisplayReportStateUpdate();

            if ( alarmStateRead() ) {
                userInterfaceDisplayAlarmStateInit();
            }
            break;

        case DISPLAY_ALARM_STATE:
            userInterfaceDisplayAlarmStateUpdate();

            if ( !alarmStateRead() ) {
                userInterfaceDisplayReportStateInit();
            }
            break;

        default:
            userInterfaceDisplayReportStateInit();
            break;
        }

    } else {
        accumulatedDisplayTime =
            accumulatedDisplayTime + SYSTEM_TIME_INCREMENT_MS;
    }
}

