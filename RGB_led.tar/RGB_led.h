//=====[#include guards - begin]===============================================

#ifndef _RGB_LED_H_
#define _RGB_LED_H_

//=====[Declaration of public defines]=========================================

//=====[Declaration of public data types]======================================

//=====[Declarations (prototypes) of public functions]=========================

void RGBLed();
void RGBLedStateRead();

//=====[#include guards - end]=================================================

#endif // _RGB_LED_H_