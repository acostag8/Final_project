//=====[Libraries]=============================================================

#include "arm_book_lib.h"

#include "ldr_sensor.h"

//=====[Declaration of private defines]========================================

//=====[Declaration and initialization of public global objects]===============

DigitalIn redLed(D11); //declares each lead of the LED to a pin on the board
DigitalIn greenLed(D12);
DigitalIn blueLed (D13);

//=====[Declaration of external public global variables]=======================
//=====[Implementations of public functions]===================================

void RGBLedInit()//initialise the LED to be off
{
    redLed = OFF;
    blueLed = OFF;
    greenLed = OFF;
}

void RGBLedStateRead()//if the function ldrSensorUpdat() returns true, (room is dark), LED is on, else LED is off 
{ if ( ldrSensorUpdate() == true ) {
    redLed = ON;  
    blueLed = ON;
    greenLed =ON;

 } else {
     redLed = OFF; 
     blueLed=OFF;
     greenLed = OFF;      
 }

}